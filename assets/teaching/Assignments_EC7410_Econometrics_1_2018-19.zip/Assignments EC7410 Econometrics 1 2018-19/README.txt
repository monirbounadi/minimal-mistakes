DESCRIPTION

Assignments in EC7410 Econometrics 1 2018-19 at Stockholm University.

Solutions can be provided upon request to people teaching econometrics at the advanced level, but not to students.

Comments welcome.

AUTHOR

Monir Elias Bounadi